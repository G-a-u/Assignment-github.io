﻿using Crud_MVC_EntityFramwork.Models;
using Microsoft.EntityFrameworkCore;

namespace Crud_MVC_EntityFramwork.Data
{
    public class ApplicationContext:DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext>options): base(options)    { }
        public DbSet<Employee> Employees { get; set; }
    }
}
