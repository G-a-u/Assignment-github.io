﻿using Crud_MVC_EntityFramwork.Data;
using Crud_MVC_EntityFramwork.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Crud_MVC_EntityFramwork.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationContext _context;

        public EmployeeController(ApplicationContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var result = _context.Employees.ToList();
            return View(result);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View(); 
        }
        [HttpPost]
        public IActionResult Create(Employee model)  
        {
            if (ModelState.IsValid)
            {
                var emp = new Employee()
                {
                    Name=model.Name,
                    City=model.City,
                    State=model.State,
                    Salary=model.Salary
                    
                };
                _context.Employees.Add(emp);
                _context.SaveChanges();
                return RedirectToAction("Index");
                
            }
            else
            {

                TempData["error"] = "Empty field can't submoit";
                return View(model);
            }
        }
        public IActionResult Edit(int id)
        {
            var emp = _context.Employees.SingleOrDefault(e=>e.Id == id);
            var result = new Employee()
            {
                Name = emp.Name,
                City = emp.City,
                State = emp.State,
                Salary = emp.Salary
            };
            return View(result);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            //Linkque use in SingleOrDefault for data fetch
            var emp = _context.Employees.FirstOrDefault(e =>e.Id == id);
            //context.Employees.Remove(emp);
            _context.Employees.Remove(emp);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
